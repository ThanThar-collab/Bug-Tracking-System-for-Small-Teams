from django.apps import AppConfig


class BugtrackerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bugtracker_app'
